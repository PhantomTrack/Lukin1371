# Исследование жизненного цикла Activity в Android

В этом документе представлены результаты исследования жизненного цикла Activity на примере простого приложения профиля пользователя.

## 1. Обычный запуск приложения

При запуске приложения методы жизненного цикла вызываются в следующей последовательности:

D/ProfileActivity: onCreate called, savedInstanceState=null
D/ProfileActivity: onStart called
D/ProfileActivity: onResume called

Обоснование: При первом запуске Activity проходит через три основных стадии:
- onCreate() - Activity создается, инициализируется UI
- onStart() - Activity становится видимой
- onResume() - Activity переходит на передний план и готова к взаимодействию с пользователем

## 2. Поворот экрана

При повороте экрана текущая Activity уничтожается и создается заново. Логи показывают следующую последовательность:

D/ProfileActivity: onPause called
D/ProfileActivity: onSaveInstanceState called
D/ProfileActivity: onStop called
D/ProfileActivity: onDestroy called
D/ProfileActivity: onCreate called, savedInstanceState=Bundle[...]
D/ProfileActivity: onStart called
D/ProfileActivity: onRestoreInstanceState called
D/ProfileActivity: onResume called

Обоснование: При изменении конфигурации (повороте экрана):
1. Система сначала останавливает текущий экземпляр Activity: onPause → onSaveInstanceState → onStop → onDestroy
2. Затем создается новый экземпляр: onCreate (с непустым Bundle) → onStart → onRestoreInstanceState (для восстановления данных) → onResume
3. onSaveInstanceState вызывается для сохранения состояния перед уничтожением Activity
4. onRestoreInstanceState вызывается после onStart, чтобы восстановить сохраненное состояние

## 3. Сворачивание приложения

При сворачивании приложения (нажатие на кнопку Home или переключение на другое приложение):

D/ProfileActivity: onPause called
D/ProfileActivity: onSaveInstanceState called
D/ProfileActivity: onStop called

При возвращении к приложению:

D/ProfileActivity: onRestart called
D/ProfileActivity: onStart called
D/ProfileActivity: onResume called

Обоснование:
- При сворачивании Activity не уничтожается, а лишь останавливается: onPause → onSaveInstanceState → onStop
- При возвращении к приложению вызывается onRestart (в отличие от поворота экрана), далее идут стандартные onStart и onResume
- onSaveInstanceState вызывается на всякий случай, если системе понадобится освободить память и уничтожить Activity

## 4. Вызов finish() в onCreate()

При добавлении finish() в метод onCreate():

D/ProfileActivity: onCreate called, savedInstanceState=null
D/ProfileActivity: onStart called
D/ProfileActivity: onResume called
D/ProfileActivity: onPause called
D/ProfileActivity: onStop called
D/ProfileActivity: onDestroy called

Обоснование:
- Activity всё равно проходит полный цикл инициализации: onCreate → onStart → onResume
- Затем сразу же начинается завершение Activity: onPause → onStop → onDestroy
- Это показывает, что finish() не останавливает выполнение метода onCreate() и последующих методов жизненного цикла, а лишь ставит Activity в очередь на завершение

## Выводы

1. Жизненный цикл Activity в Android имеет четко определенную последовательность вызовов методов
2. При изменении конфигурации (например, поворот экрана) Activity пересоздается полностью, но её состояние сохраняется и восстанавливается
3. При сворачивании приложения Activity приостанавливается, но не уничтожается (если только система не нуждается в памяти)
4. Вызов finish() в onCreate() не предотвращает выполнение других методов жизненного цикла, а лишь инициирует последовательное завершение Activity после её создания

Эти знания помогают правильно управлять ресурсами приложения и понимать, когда следует сохранять и восстанавливать состояние.