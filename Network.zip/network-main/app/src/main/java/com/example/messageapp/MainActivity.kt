package com.example.messageapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import kotlinx.coroutines.launch

// Data model
data class Post(val id: Int, var title: String, var body: String)

// Retrofit API interface
interface ApiService {
    @GET("posts")
    suspend fun getPosts(): List<Post>

    @PUT("posts/{id}")
    suspend fun updatePost(@Path("id") id: Int, @Body post: Post): Post
}

// Retrofit instance
val retrofit = Retrofit.Builder()
    .baseUrl("https://jsonplaceholder.typicode.com/")
    .addConverterFactory(GsonConverterFactory.create())
    .build()

val apiService: ApiService = retrofit.create(ApiService::class.java)

// Main activity
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MessageApp()
        }
    }
}

@Composable
fun MessageApp() {
    var posts by remember { mutableStateOf(listOf<Post>()) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        posts = apiService.getPosts()
    }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        items(posts) { post ->
            PostItem(post) {
                coroutineScope.launch {
                    val updatedPost = apiService.updatePost(post.id, post)
                    posts = posts.map { if (it.id == post.id) updatedPost else it }
                }
            }
        }
    }
}

@Composable
fun PostItem(post: Post, onUpdate: () -> Unit) {
    var title by remember { mutableStateOf(TextFieldValue(post.title)) }
    var body by remember { mutableStateOf(TextFieldValue(post.body)) }
    var isEditing by remember { mutableStateOf(false) }

    Card(modifier = Modifier.fillMaxWidth().padding(8.dp).clickable { isEditing = true }) {
        Column(modifier = Modifier.padding(16.dp)) {
            if (isEditing) {
                TextField(value = title, onValueChange = { title = it })
                TextField(value = body, onValueChange = { body = it })
                Button(onClick = {
                    post.title = title.text
                    post.body = body.text
                    onUpdate()
                    isEditing = false
                }) {
                    Text("Save")
                }
            } else {
                Text(text = "${post.id}. ${post.title}", style = MaterialTheme.typography.h6)
            }
        }
    }
}
