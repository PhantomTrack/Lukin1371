package com.example.contactnotes

import android.content.ContentResolver
import android.provider.ContactsContract
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.*
kotlinx.coroutines.launch

// Room entities and DAO
@Entity
data class ContactNote(
    @PrimaryKey val contactId: String,
    val name: String,
    var note: String
)

@Dao
interface ContactNoteDao {
    @Query("SELECT * FROM ContactNote")
    fun getAll(): List<ContactNote>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(note: ContactNote)

    @Query("DELETE FROM ContactNote WHERE contactId = :contactId")
    fun delete(contactId: String)
}

@Database(entities = [ContactNote::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun contactNoteDao(): ContactNoteDao
}


class ContactsViewModel(private val contentResolver: ContentResolver, private val db: AppDatabase) : ViewModel() {
    var contacts by mutableStateOf(listOf<ContactNote>())
        private set

    init {
        loadContacts()
    }

    private fun loadContacts() {
        viewModelScope.launch {
            val cursor = contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI, null, null, null, null
            )
            val notes = db.contactNoteDao().getAll().associateBy { it.contactId }
            val contactList = mutableListOf<ContactNote>()
            cursor?.use {
                val idIndex = it.getColumnIndex(ContactsContract.Contacts._ID)
                val nameIndex = it.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)
                while (it.moveToNext()) {
                    val id = it.getString(idIndex)
                    val name = it.getString(nameIndex)
                    contactList.add(notes[id] ?: ContactNote(id, name, ""))
                }
            }
            contacts = contactList
        }
    }

    fun updateNote(contact: ContactNote) {
        viewModelScope.launch {
            db.contactNoteDao().insert(contact)
            loadContacts()
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "contacts-db").build()
        val viewModel = ContactsViewModel(contentResolver, database)
        setContent {
            ContactsApp(viewModel)
        }
    }
}

@Composable
fun ContactsApp(viewModel: ContactsViewModel) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        items(viewModel.contacts) { contact ->
            ContactItem(contact) { newNote ->
                viewModel.updateNote(contact.copy(note = newNote))
            }
        }
    }
}

@Composable
fun ContactItem(contact: ContactNote, onUpdate: (String) -> Unit) {
    var note by remember { mutableStateOf(TextFieldValue(contact.note)) }
    var isEditing by remember { mutableStateOf(false) }

    Card(modifier = Modifier.fillMaxWidth().padding(8.dp).clickable { isEditing = true }) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = contact.name, style = MaterialTheme.typography.h6)
            if (isEditing) {
                TextField(value = note, onValueChange = { note = it })
                Button(onClick = {
                    onUpdate(note.text)
                    isEditing = false
                }) {
                    Text("Save")
                }
            } else {
                Text(text = contact.note)
            }
        }
    }
}
